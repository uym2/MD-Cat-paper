#! /bin/bash

for x in scenario{4,5}; do
    for y in $x/rep*; do
        echo $y
        mkdir $y/reltime_results
        megacc -a reltime_blens.mao -t $y/phylogram.tre -c calibrations.txt -o $y/reltime_results/reltime -g groups.txt  
        tempTree1=`mktemp`
        tempTree2=`mktemp`
        cat $y/reltime_results/reltime_exactTimes.nwk | sed -e "s/\'//g"  > $tempTree1
        matchLabels.py -i $tempTree1 -o $tempTree2 -r chronogram.tre
        nw_prune $tempTree2 Emporia  > $y/chronogram.reltime.tre
        nw_distance $y/chronogram.reltime.tre | head -n1
        rm $tempTree1 $tempTree2
    done
done
